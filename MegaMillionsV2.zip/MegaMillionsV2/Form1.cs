﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MegaMillions
{
    public partial class Form1 : Form
    {
        private Random rand;
        private int winCount = 0;
        private int lossCount = 0;

        public Form1()
        {
            InitializeComponent();
            this.Text = "Lottery Number Generator";
            rand = new Random(); // Initialize Random instance
        }

        private void btnDraw_Click(object sender, EventArgs e)
        {
            try
            {
                int maxNumber;
                int extraNumberMax;
                string gameName;

                // Validate user input and set game parameters
                if (rbMegaMillions.Checked)
                {
                    maxNumber = 70;
                    extraNumberMax = 25;
                    gameName = "Mega Millions";
                }
                else if (rbPowerBall.Checked)
                {
                    maxNumber = 69;
                    extraNumberMax = 26;
                    gameName = "Powerball";
                }
                else
                {
                    MessageBox.Show("Please select a game (Mega Millions or Powerball).");
                    return;
                }

                // Generate user's numbers
                var userNumbers = GenerateNumbers(maxNumber, 5);
                var userExtraNumber = rand.Next(1, extraNumberMax + 1);

                // Generate winning numbers
                var winningNumbers = GenerateNumbers(maxNumber, 5);
                var winningExtraNumber = rand.Next(1, extraNumberMax + 1);

                // Compare numbers to determine win or loss
                bool isWin = IsWinningTicket(userNumbers, userExtraNumber, winningNumbers, winningExtraNumber);

                if (isWin)
                {
                    winCount++;
                    lblResult.Text = "Result: You Won!";
                }
                else
                {
                    lossCount++;
                    lblResult.Text = "Result: You Lost!";
                }

                // Update the win-loss counter labels
                lblWinCount.Text = $"Wins: {winCount}";
                lblLossCount.Text = $"Losses: {lossCount}";

                // Display numbers
                this.Text = $"{gameName} Number Generator";
                lblNumbers.Text = $"Your Numbers: {string.Join(", ", userNumbers)} + {userExtraNumber}\n" +
                                  $"Winning Numbers: {string.Join(", ", winningNumbers)} + {winningExtraNumber}";
            }
            catch (Exception ex)
            {
                MessageBox.Show("An unexpected error occurred:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private List<int> GenerateNumbers(int max, int count)
        {
            HashSet<int> numbers = new HashSet<int>();
            while (numbers.Count < count)
            {
                numbers.Add(rand.Next(1, max + 1));
            }
            var numberList = new List<int>(numbers);
            numberList.Sort(); // Sort the numbers for better readability
            return numberList;
        }

        private bool IsWinningTicket(List<int> userNumbers, int userExtra, List<int> winningNumbers, int winningExtra)
        {
            // Check if main numbers match
            bool mainNumbersMatch = new HashSet<int>(userNumbers).SetEquals(winningNumbers);
            // Check if the extra number matches
            bool extraNumberMatch = userExtra == winningExtra;

            // For a win, both main numbers and the extra number must match
            return mainNumbersMatch && extraNumberMatch;
        }
    }
}
