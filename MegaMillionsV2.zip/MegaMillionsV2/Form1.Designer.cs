﻿namespace MegaMillions
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.btnDraw = new System.Windows.Forms.Button();
            this.lblNumbers = new System.Windows.Forms.Label();
            this.lblInstructions = new System.Windows.Forms.Label();
            this.rbMegaMillions = new System.Windows.Forms.RadioButton();
            this.rbPowerBall = new System.Windows.Forms.RadioButton();
            this.lblResult = new System.Windows.Forms.Label();
            this.lblWinCount = new System.Windows.Forms.Label();
            this.lblLossCount = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblInstructions
            // 
            this.lblInstructions.AutoSize = true;
            this.lblInstructions.Location = new System.Drawing.Point(12, 20);
            this.lblInstructions.Name = "lblInstructions";
            this.lblInstructions.Size = new System.Drawing.Size(183, 13);
            this.lblInstructions.TabIndex = 2;
            this.lblInstructions.Text = "Select a game and click \"Draw\" below.";
            // 
            // rbMegaMillions
            // 
            this.rbMegaMillions.AutoSize = true;
            this.rbMegaMillions.Location = new System.Drawing.Point(15, 50);
            this.rbMegaMillions.Name = "rbMegaMillions";
            this.rbMegaMillions.Size = new System.Drawing.Size(89, 17);
            this.rbMegaMillions.TabIndex = 3;
            this.rbMegaMillions.TabStop = true;
            this.rbMegaMillions.Text = "Mega Millions";
            this.rbMegaMillions.UseVisualStyleBackColor = true;
            // 
            // rbPowerBall
            // 
            this.rbPowerBall.AutoSize = true;
            this.rbPowerBall.Location = new System.Drawing.Point(15, 73);
            this.rbPowerBall.Name = "rbPowerBall";
            this.rbPowerBall.Size = new System.Drawing.Size(74, 17);
            this.rbPowerBall.TabIndex = 4;
            this.rbPowerBall.TabStop = true;
            this.rbPowerBall.Text = "Powerball";
            this.rbPowerBall.UseVisualStyleBackColor = true;
            // 
            // btnDraw
            // 
            this.btnDraw.Location = new System.Drawing.Point(100, 100);
            this.btnDraw.Name = "btnDraw";
            this.btnDraw.Size = new System.Drawing.Size(75, 23);
            this.btnDraw.TabIndex = 0;
            this.btnDraw.Text = "Draw";
            this.btnDraw.UseVisualStyleBackColor = true;
            this.btnDraw.Click += new System.EventHandler(this.btnDraw_Click);
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult.Location = new System.Drawing.Point(12, 140);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(0, 17);
            this.lblResult.TabIndex = 5;
            // 
            // lblNumbers
            // 
            this.lblNumbers.AutoSize = true;
            this.lblNumbers.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumbers.Location = new System.Drawing.Point(12, 170);
            this.lblNumbers.Name = "lblNumbers";
            this.lblNumbers.Size = new System.Drawing.Size(0, 17);
            this.lblNumbers.TabIndex = 1;
            // 
            // lblWinCount
            // 
            this.lblWinCount.AutoSize = true;
            this.lblWinCount.Location = new System.Drawing.Point(12, 225); // Moved down from 210
            this.lblWinCount.Name = "lblWinCount";
            this.lblWinCount.Size = new System.Drawing.Size(41, 13);
            this.lblWinCount.TabIndex = 6;
            this.lblWinCount.Text = "Wins: 0";
            // 
            // lblLossCount
            // 
            this.lblLossCount.AutoSize = true;
            this.lblLossCount.Location = new System.Drawing.Point(12, 245); // Moved down from 230
            this.lblLossCount.Name = "lblLossCount";
            this.lblLossCount.Size = new System.Drawing.Size(51, 13);
            this.lblLossCount.TabIndex = 7;
            this.lblLossCount.Text = "Losses: 0";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(350, 275); // Increased height to accommodate moved labels
            this.Controls.Add(this.lblLossCount);
            this.Controls.Add(this.lblWinCount);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.rbPowerBall);
            this.Controls.Add(this.rbMegaMillions);
            this.Controls.Add(this.lblInstructions);
            this.Controls.Add(this.lblNumbers);
            this.Controls.Add(this.btnDraw);
            this.Name = "Form1";
            this.Text = "Lottery Number Generator";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button btnDraw;
        private System.Windows.Forms.Label lblNumbers;
        private System.Windows.Forms.Label lblInstructions;
        private System.Windows.Forms.RadioButton rbMegaMillions;
        private System.Windows.Forms.RadioButton rbPowerBall;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label lblWinCount;
        private System.Windows.Forms.Label lblLossCount;
    }
}
