﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MegaMillions
{
    public partial class fMain : Form
    {
        int[] mega = new int[6];
        Random rnd = new Random();
        Label[] labels = new Label[6];

        public fMain()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPick_Click(object sender, EventArgs e)
        {
            //pick numbers
            PickNumbers();
            //populate the labels
            ShowNumbers();
            btnPick.Enabled = false;
            btnClear.Enabled = true;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //clear the labels
            foreach (Label l in labels)
            {
                l.Text = "";
            }
            btnClear.Enabled = false;
            btnPick.Enabled= true;
        }
        private void PickNumbers()
        {
           
            for (int i=0;i<mega.Length; i++) 
            {
                mega[i] = rnd.Next(1,71);
                if (i > 0) 
                {
                    int currPick = i;
                    for (int j=0;j<currPick;j++) 
                    {
                        if (mega[currPick] == mega[j])
                        {
                            i--;
                            break;
                        }
                    }
                
                }
            }
            mega[5] = rnd.Next(1, 26);
        }
        private void ShowNumbers()
        {
            for (int i=0;i< mega.Length;i++) 
            {
                labels[i].Text = mega[i].ToString();
            }
        }

        private void fMain_Load(object sender, EventArgs e)
        {
            labels[0] = label1;
            labels[1] = label2;
            labels[2] = label3;
            labels[3] = label4;
            labels[4] = label5;
            labels[5] = label6;
        }
    }
}
